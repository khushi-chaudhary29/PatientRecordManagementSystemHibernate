package com.patient;

import org.hibernate.Session;

import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import java.util.List;

public class PatientDAO {
		private SessionFactory sessionFactory;

		public PatientDAO(SessionFactory sessionFactory) {
			super();
			this.sessionFactory = sessionFactory;
		}
		
		public void insertEntity(Patient entity) {
			Session session = sessionFactory.openSession();
			Transaction transaction=null;
			try {
				transaction = session.beginTransaction();
				session.save(entity);
				transaction.commit();
				System.out.println("Entity inserted successfully.");
			}catch(Exception e) {
				if(transaction != null) {
					transaction.rollback();
				}
				e.printStackTrace();
			}finally {
	            if (session != null) {
	                session.close(); // Ensure the session is closed
	            }
	        }
			
		}
		public List<Patient> fetchAllRecords() {
	        Session session = sessionFactory.openSession();
	        Transaction transaction = null;
	        List<Patient> records = null;

	        try {
	            transaction = session.beginTransaction();

	            // Using HQL to fetch all records
	            Query<Patient> query = session.createQuery("FROM Patient", Patient.class);
	            records = query.getResultList();

	            transaction.commit();
	        } catch (Exception e) {
	            if (transaction != null) {
	                transaction.rollback();
	            }
	            e.printStackTrace();
	        } finally {
	            session.close();
	        }

	        return records;
	    }
		
		public Patient getById(int patientId) {
	    	Session session = sessionFactory.openSession();
	        Transaction transaction = null;
	        Patient entity = null;

	        try {
	            transaction = session.beginTransaction();

	            // HQL query to fetch data by ID
	            String hql = "FROM Patient WHERE patientId = :patientId";
	            Query<Patient> query = session.createQuery(hql, Patient.class);
	            query.setParameter("patientId", patientId);

	            // Retrieve the single result
	            entity = query.uniqueResult();

	            transaction.commit();
	        } catch (Exception e) {
	            if (transaction != null) {
	                transaction.rollback();
	            }
	            e.printStackTrace();
	        }

	        return entity;
	    }
		public void updateNameById(int patientId, String newName) {
	        Transaction transaction = null;
	        try {
	        	Session session = sessionFactory.openSession();
	        
	            transaction = session.beginTransaction();

	            // HQL update query
	            String hql = "UPDATE Patient SET pName = :newName WHERE patientId = :patientId";
	            Query query = session.createQuery(hql);
	            query.setParameter("newName", newName);
	            query.setParameter("patientId", patientId);

	            int rowsAffected = query.executeUpdate(); // Execute update
	            System.out.println("Rows affected: " + rowsAffected);

	            transaction.commit();
	        } catch (Exception e) {
	            if (transaction != null) {
	                transaction.rollback();
	            }
	            e.printStackTrace();
	        }
		}
		public void deleteById(int patientId) {
	        Transaction transaction = null;
	        try {
	        	Session session = sessionFactory.openSession();
	        
	            transaction = session.beginTransaction();

	            // HQL delete query
	            String hql = "DELETE FROM Patient WHERE patientId = :patientId";
	            Query query = session.createQuery(hql);
	            query.setParameter("patientId", patientId);

	            int rowsAffected = query.executeUpdate(); // Execute delete
	            System.out.println("Rows affected: " + rowsAffected);

	            transaction.commit();
	        } catch (Exception e) {
	            if (transaction != null) {
	                transaction.rollback();
	            }
	            e.printStackTrace();
	        }
		}
}
