package com.patient;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import java.util.List;

public class DoctorDAO {
    private SessionFactory factory;

    public DoctorDAO(SessionFactory factory) {
        this.factory = factory;
    }

    public void insertEntity(Doctor doctor) {
        Session session = factory.openSession();
        Transaction transaction = session.beginTransaction();
        session.save(doctor);
        transaction.commit();
        session.close();
    }

    public List<Doctor> fetchAllRecords() {
        Session session = factory.openSession();
        List<Doctor> records = session.createQuery("from Doctor", Doctor.class).list();
        session.close();
        return records;
    }

    public Doctor getById(int doctorId) {
        Session session = factory.openSession();
        Doctor doctor = session.get(Doctor.class, doctorId);
        session.close();
        return doctor;
    }

    public void updateContactNumberById(int doctorId, String newContactNumber) {
        Session session = factory.openSession();
        Transaction transaction = session.beginTransaction();
        Doctor doctor = session.get(Doctor.class, doctorId);
        if (doctor != null) {
            doctor.setContactNumber(newContactNumber);
            session.update(doctor);
        }
        transaction.commit();
        session.close();
    }

    public void deleteById(int doctorId) {
        Session session = factory.openSession();
        Transaction transaction = session.beginTransaction();
        Doctor doctor = session.get(Doctor.class, doctorId);
        if (doctor != null) {
            session.delete(doctor);
        }
        transaction.commit();
        session.close();
    }
}
