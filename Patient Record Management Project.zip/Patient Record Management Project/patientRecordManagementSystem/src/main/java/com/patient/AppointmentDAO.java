package com.patient;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import java.util.List;

public class AppointmentDAO {
    private SessionFactory factory;

    public AppointmentDAO(SessionFactory factory) {
        this.factory = factory;
    }

    public void insertEntity(Appointment appointment) {
        Session session = factory.openSession();
        Transaction transaction = session.beginTransaction();
        session.save(appointment);
        transaction.commit();
        session.close();
    }

    public List<Appointment> fetchAllRecords() {
        Session session = factory.openSession();
        List<Appointment> records = session.createQuery("from Appointment", Appointment.class).list();
        session.close();
        return records;
    }

    public Appointment getById(int appointmentId) {
        Session session = factory.openSession();
        Appointment appointment = session.get(Appointment.class, appointmentId);
        session.close();
        return appointment;
    }

    public void updateStatusById(int appointmentId, String newStatus) {
        Session session = factory.openSession();
        Transaction transaction = session.beginTransaction();
        Appointment appointment = session.get(Appointment.class, appointmentId);
        if (appointment != null) {
            appointment.setStatus(newStatus);
            session.update(appointment);
        }
        transaction.commit();
        session.close();
    }

    public void deleteById(int appointmentId) {
        Session session = factory.openSession();
        Transaction transaction = session.beginTransaction();
        Appointment appointment = session.get(Appointment.class, appointmentId);
        if (appointment != null) {
            session.delete(appointment);
        }
        transaction.commit();
        session.close();
    }
}
